
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;


public class Delete extends javax.swing.JFrame {

    public Delete() {
        initComponents();
    }
    private String accountIdToDelete;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        Account_ID = new javax.swing.JTextField();
        Delete_Button = new javax.swing.JButton();
        Back = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1050, 800));
        setPreferredSize(new java.awt.Dimension(798, 521));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Account_ID.setBackground(new java.awt.Color(153, 153, 153));
        Account_ID.setToolTipText("Account ID");
        Account_ID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Account_IDActionPerformed(evt);
            }
        });
        getContentPane().add(Account_ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 270, 270, 30));

        Delete_Button.setBackground(new java.awt.Color(153, 153, 153));
        Delete_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Delete_Button.setText("Delete");
        Delete_Button.setToolTipText("Delete Account");
        Delete_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_ButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Delete_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 390, 180, 30));

        Back.setBackground(new java.awt.Color(153, 153, 153));
        Back.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        getContentPane().add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 390, 180, 30));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 153, 153));
        jLabel2.setText("ID");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 270, 50, -1));
        jLabel2.getAccessibleContext().setAccessibleDescription("");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/atm.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -20, 970, 800));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Delete_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_ButtonActionPerformed
       
        String accountIdText = Account_ID.getText().trim();
        if (accountIdText.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter a valid account ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String filename = "database.txt";
        String tempFilename = "temp_database.txt";
        File file = new File(filename);
        File tempFile = new File(tempFilename);
        boolean accountDeleted = false;

        try (BufferedReader br = new BufferedReader(new FileReader(file));
             BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 10 && parts[0].equals(accountIdText)) {
                    accountDeleted = true;
                    continue;
                }
                bw.write(line + System.getProperty("line.separator"));
            }

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occurred while deleting account.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!file.delete()) {
            JOptionPane.showMessageDialog(null, "Error occurred while deleting account.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!tempFile.renameTo(file)) {
            JOptionPane.showMessageDialog(null, "Error occurred while deleting account.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (accountDeleted) {
            JOptionPane.showMessageDialog(null, "Account deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Account was not found in the database.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Clear the text field after deletion
        Account_ID.setText("");
        
    
    }//GEN-LAST:event_Delete_ButtonActionPerformed

    private void Account_IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Account_IDActionPerformed
      accountIdToDelete = Account_ID.getText().trim();
        

    }//GEN-LAST:event_Account_IDActionPerformed

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        new Admin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Delete.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Delete.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Delete.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Delete.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Delete.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Delete().setVisible(true);
                
                //  new Add_User().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Account_ID;
    private javax.swing.JButton Back;
    private javax.swing.JButton Delete_Button;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables

}
