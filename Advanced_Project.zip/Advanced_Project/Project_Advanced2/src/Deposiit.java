
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Deposiit extends javax.swing.JFrame {

    public String cardId;

    public Deposiit() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        DepositAmout = new javax.swing.JTextField();
        BackButton = new javax.swing.JButton();
        DepositButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(960, 762));
        setMinimumSize(new java.awt.Dimension(960, 762));
        setPreferredSize(new java.awt.Dimension(960, 762));
        setResizable(false);
        setSize(new java.awt.Dimension(960, 762));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Enter Amout You Want To Deposit");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, -1, 65));

        DepositAmout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DepositAmoutActionPerformed(evt);
            }
        });
        getContentPane().add(DepositAmout, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 260, 235, -1));

        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        getContentPane().add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 370, 140, 50));

        DepositButton.setText("Deposit");
        DepositButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DepositButtonActionPerformed(evt);
            }
        });
        getContentPane().add(DepositButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 370, 140, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/atm.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 760));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DepositAmoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DepositAmoutActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DepositAmoutActionPerformed

    private void DepositButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DepositButtonActionPerformed
        String depositAmountText = DepositAmout.getText();
        System.out.println(this.cardId);
        try {
            int depositAmount = Integer.parseInt(depositAmountText);
            // Call the depositCash method to write to the file
            depositCash(depositAmount);
            // Clear the text field after depositing
            DepositAmout.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
        }
    }//GEN-LAST:event_DepositButtonActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // Create an instance of the User class
        User userWindow = new User();
        userWindow.cardId = this.cardId;
        
        // Make the User window visible
        userWindow.setVisible(true);

        // Hide the FastCash window
        this.setVisible(false);    }//GEN-LAST:event_BackButtonActionPerformed

// Method to deposit cash into the account and write to the file
    private void depositCash(int amount) {
        File dbFile = new File("database.txt");
        StringBuilder updatedContent = new StringBuilder();
        boolean updateSuccess = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(dbFile))) {
            String currentLine;

            while ((currentLine = reader.readLine()) != null) {
                String[] userDetails = currentLine.split(",");
                if (userDetails[0].equals(this.cardId)) {
                    // Assuming balance is the last element in userDetails
                    int currentBalance = Integer.parseInt(userDetails[userDetails.length - 1]);
                    int newBalance = currentBalance + amount;
                    userDetails[userDetails.length - 1] = String.valueOf(newBalance);

                    // Notify user of successful deposit
                    JOptionPane.showMessageDialog(null, "Successfully deposited EGP " + amount + ". New balance: EGP " + newBalance);

                    // Update the current line with the new balance
                    currentLine = String.join(",", userDetails);
                    updateSuccess = true;
                }
                // Append the possibly modified line to the StringBuilder
                updatedContent.append(currentLine).append(System.lineSeparator());
            }
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Write all content back to the file only if an update was successful
        if (updateSuccess) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(dbFile, false))) {
                writer.write(updatedContent.toString());
                JOptionPane.showMessageDialog(null, "Balance updated successfully.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Failed to update the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "User ID not found. No update performed.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Deposiit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Deposiit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Deposiit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Deposiit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Deposiit().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JTextField DepositAmout;
    private javax.swing.JButton DepositButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
