
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Withdrawl extends javax.swing.JFrame {

    public String cardId;

    public Withdrawl() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        WithdrawalAmount = new javax.swing.JTextField();
        WithdrawButton = new javax.swing.JButton();
        BackButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Enter Amount To Withdraw");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 180, -1, 50));

        WithdrawalAmount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WithdrawalAmountActionPerformed(evt);
            }
        });
        getContentPane().add(WithdrawalAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 187, -1));

        WithdrawButton.setText("Withdraw");
        WithdrawButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WithdrawButtonActionPerformed(evt);
            }
        });
        getContentPane().add(WithdrawButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 370, 140, 50));

        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        getContentPane().add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 370, 140, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/atm.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void WithdrawalAmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WithdrawalAmountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_WithdrawalAmountActionPerformed

    private void WithdrawButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WithdrawButtonActionPerformed
        String withdrawalAmountText = WithdrawalAmount.getText();
        System.out.println(this.cardId);
        try {
            int withdrawalAmount = Integer.parseInt(withdrawalAmountText);
            // Call the withdrawCash method to update the file
            withdrawCash(withdrawalAmount);
            // Clear the text field after withdrawing
            WithdrawalAmount.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
        }    }//GEN-LAST:event_WithdrawButtonActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // Create an instance of the User class
        User userWindow = new User();
        userWindow.cardId = this.cardId;
        // Make the User window visible
        userWindow.setVisible(true);

        // Hide the FastCash window
        this.setVisible(false);    }//GEN-LAST:event_BackButtonActionPerformed

    private void withdrawCash(int amount) {
        File dbFile = new File("database.txt");
        StringBuilder updatedContent = new StringBuilder();
        boolean updateSuccess = false;
        boolean insufficientFunds = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(dbFile))) {
            String currentLine;

            while ((currentLine = reader.readLine()) != null) {
                String[] userDetails = currentLine.split(",");
                if (userDetails[0].equals(this.cardId)) {
                    // Assuming balance is the last element in userDetails
                    int currentBalance = Integer.parseInt(userDetails[userDetails.length - 1]);

                    if (currentBalance >= amount) {
                        int newBalance = currentBalance - amount;
                        userDetails[userDetails.length - 1] = String.valueOf(newBalance);

                        // Notify user of successful withdrawal
                        JOptionPane.showMessageDialog(null, "Successfully withdrew EGP " + amount + ". New balance: EGP " + newBalance);

                        // Update the current line with the new balance
                        currentLine = String.join(",", userDetails);
                        updateSuccess = true;
                    } else {
                        // Set flag for insufficient funds
                        insufficientFunds = true;
                    }
                }
                // Append the possibly modified line to the StringBuilder
                updatedContent.append(currentLine).append(System.lineSeparator());
            }
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Write all content back to the file only if an update was successful and sufficient funds were available
        if (updateSuccess) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(dbFile, false))) {
                writer.write(updatedContent.toString());
                JOptionPane.showMessageDialog(null, "Balance updated successfully.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Failed to update the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (insufficientFunds) {
            JOptionPane.showMessageDialog(null, "Insufficient balance to perform withdrawal.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "User ID not found. No update performed.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Withdrawl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Withdrawl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Withdrawl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Withdrawl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Withdrawl().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JButton WithdrawButton;
    private javax.swing.JTextField WithdrawalAmount;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
