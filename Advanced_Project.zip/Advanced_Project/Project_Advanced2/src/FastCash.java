
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class FastCash extends javax.swing.JFrame {

    public String cardId;

    public FastCash() {
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        button100EGP = new javax.swing.JButton();
        button1500EGP = new javax.swing.JButton();
        button500EGP = new javax.swing.JButton();
        button1000EGP = new javax.swing.JButton();
        button2000EGP = new javax.swing.JButton();
        button3000EGP = new javax.swing.JButton();
        BackButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Select Withdrawal Amount");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, -1, 57));

        button100EGP.setText("100 EGP");
        button100EGP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button100EGPActionPerformed(evt);
            }
        });
        getContentPane().add(button100EGP, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 260, 140, 40));

        button1500EGP.setText("1,500 EGP");
        button1500EGP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1500EGPActionPerformed(evt);
            }
        });
        getContentPane().add(button1500EGP, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 260, 140, 40));

        button500EGP.setText("500 EGP");
        button500EGP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button500EGPActionPerformed(evt);
            }
        });
        getContentPane().add(button500EGP, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 300, 140, 40));

        button1000EGP.setText("1000 EGP");
        button1000EGP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1000EGPActionPerformed(evt);
            }
        });
        getContentPane().add(button1000EGP, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, 140, 40));

        button2000EGP.setText("2,000 EGP");
        button2000EGP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2000EGPActionPerformed(evt);
            }
        });
        getContentPane().add(button2000EGP, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 300, 140, 40));

        button3000EGP.setText("3,000 EGP");
        button3000EGP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3000EGPActionPerformed(evt);
            }
        });
        getContentPane().add(button3000EGP, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 340, 140, 40));

        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        getContentPane().add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 380, 140, 40));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/atm.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 760));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button100EGPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button100EGPActionPerformed
        System.out.println(this.cardId);
        withdrawAmount(100);
    }//GEN-LAST:event_button100EGPActionPerformed

    private void button500EGPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button500EGPActionPerformed
        System.out.println(this.cardId);
        withdrawAmount(500);
    }//GEN-LAST:event_button500EGPActionPerformed

    private void button1000EGPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1000EGPActionPerformed
        System.out.println(this.cardId);
        withdrawAmount(1000);
    }//GEN-LAST:event_button1000EGPActionPerformed

    private void button1500EGPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1500EGPActionPerformed
        System.out.println(this.cardId);
        withdrawAmount(1500);
    }//GEN-LAST:event_button1500EGPActionPerformed

    private void button2000EGPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2000EGPActionPerformed
        System.out.println(this.cardId);
        withdrawAmount(2000);
    }//GEN-LAST:event_button2000EGPActionPerformed

    private void button3000EGPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3000EGPActionPerformed
        System.out.println(this.cardId);
        withdrawAmount(3000);
    }//GEN-LAST:event_button3000EGPActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // Create an instance of the User class

        User userWindow = new User();
        userWindow.cardId = this.cardId;
        // Make the User window visible
        userWindow.setVisible(true);

        // Hide the FastCash window
        this.setVisible(false);    }//GEN-LAST:event_BackButtonActionPerformed

    // Method to withdraw the specified amount from the balance
    private void withdrawAmount(int amount) {
        File dbFile = new File("database.txt");
        StringBuilder updatedContent = new StringBuilder();
        boolean updateSuccess = false;
        boolean insufficientFunds = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(dbFile))) {
            String currentLine;

            while ((currentLine = reader.readLine()) != null) {
                String[] userDetails = currentLine.split(",");
                if (userDetails[0].equals(this.cardId)) {
                    // Assuming balance is the last element in userDetails
                    int currentBalance = Integer.parseInt(userDetails[userDetails.length - 1]);

                    if (currentBalance >= amount) {
                        int newBalance = currentBalance - amount;
                        userDetails[userDetails.length - 1] = String.valueOf(newBalance);

                        // Update the current line with the new balance
                        currentLine = String.join(",", userDetails);
                        updateSuccess = true;

                        // Notify user of successful withdrawal
                        JOptionPane.showMessageDialog(null, "Successfully withdrew EGP " + amount + ". New balance: EGP " + newBalance);
                    } else {
                        // Set flag for insufficient funds
                        insufficientFunds = true;
                    }
                }
                // Append the possibly modified line to the StringBuilder
                updatedContent.append(currentLine).append(System.lineSeparator());
            }
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Write all content back to the file only if an update was successful and sufficient funds were available
        if (updateSuccess) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(dbFile, false))) {
                writer.write(updatedContent.toString());
                JOptionPane.showMessageDialog(null, "Balance updated successfully.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Failed to update the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (insufficientFunds) {
            JOptionPane.showMessageDialog(null, "Insufficient balance to perform withdrawal.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "User ID not found. No update performed.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FastCash.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FastCash.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FastCash.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FastCash.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FastCash().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JButton button1000EGP;
    private javax.swing.JButton button100EGP;
    private javax.swing.JButton button1500EGP;
    private javax.swing.JButton button2000EGP;
    private javax.swing.JButton button3000EGP;
    private javax.swing.JButton button500EGP;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
