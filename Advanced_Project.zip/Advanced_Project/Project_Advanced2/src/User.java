
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class User extends javax.swing.JFrame {

    public String cardId;

    public User() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DepositButton = new javax.swing.JButton();
        WithdrawalButton = new javax.swing.JButton();
        CheckBalanceButton = new javax.swing.JButton();
        FastCashButton = new javax.swing.JButton();
        LogOutButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        DepositButton.setText("Deposit");
        DepositButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DepositButtonActionPerformed(evt);
            }
        });
        getContentPane().add(DepositButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 260, 140, 40));

        WithdrawalButton.setText("Withdrawal");
        WithdrawalButton.setMaximumSize(new java.awt.Dimension(110, 27));
        WithdrawalButton.setMinimumSize(new java.awt.Dimension(110, 27));
        WithdrawalButton.setPreferredSize(new java.awt.Dimension(110, 27));
        WithdrawalButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WithdrawalButtonActionPerformed(evt);
            }
        });
        getContentPane().add(WithdrawalButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 260, 140, 40));

        CheckBalanceButton.setText("Check Balance");
        CheckBalanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckBalanceButtonActionPerformed(evt);
            }
        });
        getContentPane().add(CheckBalanceButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 310, 140, 40));

        FastCashButton.setText("Fast Cash");
        FastCashButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FastCashButtonActionPerformed(evt);
            }
        });
        getContentPane().add(FastCashButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 310, 140, 40));

        LogOutButton.setText("Log Out");
        LogOutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogOutButtonActionPerformed(evt);
            }
        });
        getContentPane().add(LogOutButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 370, 140, 50));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Please Select Your Transaction");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, -1, 27));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/atm.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DepositButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DepositButtonActionPerformed
        Deposiit userWindow = new Deposiit();
        userWindow.cardId = this.cardId;
        userWindow.setVisible(true);
        this.setVisible(false);    }//GEN-LAST:event_DepositButtonActionPerformed

    private void LogOutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogOutButtonActionPerformed
        ATM userWindow = new ATM();
        userWindow.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_LogOutButtonActionPerformed

    private void WithdrawalButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WithdrawalButtonActionPerformed
        Withdrawl userWindow = new Withdrawl();
        userWindow.cardId = this.cardId;
        userWindow.setVisible(true);
        this.setVisible(false);    }//GEN-LAST:event_WithdrawalButtonActionPerformed

    private void FastCashButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FastCashButtonActionPerformed
        FastCash userWindow = new FastCash();
        userWindow.cardId = this.cardId;
        userWindow.setVisible(true);
        this.setVisible(false);    }//GEN-LAST:event_FastCashButtonActionPerformed

    private void CheckBalanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckBalanceButtonActionPerformed
        try {
            File file = new File("database.txt");
            Scanner scanner = new Scanner(file);
            boolean found = false;

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] userDetails = line.split(",");

                // Assuming the ID is stored as the first element in the userDetails array
                if (userDetails[0].equals(this.cardId)) {
                    // Assuming the balance is the last element in the userDetails array
                    String balance = userDetails[userDetails.length - 1];
                    JOptionPane.showMessageDialog(this, "Your current balance is: " + balance + " EGP", "Balance", JOptionPane.INFORMATION_MESSAGE);
                    found = true;
                    break;
                }
            }
            scanner.close();

            if (!found) {
                JOptionPane.showMessageDialog(this, "Account not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Error: database file not found.", "Error", JOptionPane.ERROR_MESSAGE);

        }    }//GEN-LAST:event_CheckBalanceButtonActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new User().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CheckBalanceButton;
    private javax.swing.JButton DepositButton;
    private javax.swing.JButton FastCashButton;
    private javax.swing.JButton LogOutButton;
    private javax.swing.JButton WithdrawalButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
