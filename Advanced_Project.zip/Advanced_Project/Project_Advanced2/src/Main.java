public class Main {
    public static void main(String[] args) {
        ATM initForm = new ATM();
        initForm.setVisible(true);
        
    }
}
